package von.com.au.trackinternet

import androidx.core.content.FileProvider

/**
 * class for file provider
 * allows us to access private files
 */
class MyGenericFileProvider : FileProvider()